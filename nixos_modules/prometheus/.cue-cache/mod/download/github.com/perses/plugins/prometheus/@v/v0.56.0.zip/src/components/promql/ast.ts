// Copyright 2024 The Perses Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Forked from https://github.com/prometheus/prometheus/blob/65f610353919b1c7b42d3776c3a95b68046a6bba/web/ui/mantine-ui/src/promql/ast.ts

export enum nodeType {
  aggregation = 'aggregation',
  binaryExpr = 'binaryExpr',
  call = 'call',
  matrixSelector = 'matrixSelector',
  subquery = 'subquery',
  numberLiteral = 'numberLiteral',
  parenExpr = 'parenExpr',
  stringLiteral = 'stringLiteral',
  unaryExpr = 'unaryExpr',
  vectorSelector = 'vectorSelector',
  placeholder = 'placeholder',
}

export enum aggregationType {
  sum = 'sum',
  min = 'min',
  max = 'max',
  avg = 'avg',
  stddev = 'stddev',
  stdvar = 'stdvar',
  count = 'count',
  group = 'group',
  countValues = 'count_values',
  bottomk = 'bottomk',
  topk = 'topk',
  quantile = 'quantile',
  limitK = 'limitk',
  limitRatio = 'limit_ratio',
}

export enum binaryOperatorType {
  add = '+',
  sub = '-',
  mul = '*',
  div = '/',
  mod = '%',
  pow = '^',
  eql = '==',
  neq = '!=',
  gtr = '>',
  lss = '<',
  gte = '>=',
  lte = '<=',
  and = 'and',
  or = 'or',
  unless = 'unless',
  atan2 = 'atan2',
}

export const compOperatorTypes: binaryOperatorType[] = [
  binaryOperatorType.eql,
  binaryOperatorType.neq,
  binaryOperatorType.gtr,
  binaryOperatorType.lss,
  binaryOperatorType.gte,
  binaryOperatorType.lte,
];

export const setOperatorTypes: binaryOperatorType[] = [
  binaryOperatorType.and,
  binaryOperatorType.or,
  binaryOperatorType.unless,
];

export enum unaryOperatorType {
  plus = '+',
  minus = '-',
}

export enum vectorMatchCardinality {
  oneToOne = 'one-to-one',
  manyToOne = 'many-to-one',
  oneToMany = 'one-to-many',
  manyToMany = 'many-to-many',
}

export enum valueType {
  // TODO: 'none' should never make it out of Prometheus. Do we need this here?
  none = 'none',
  vector = 'vector',
  scalar = 'scalar',
  matrix = 'matrix',
  string = 'string',
}

export enum matchType {
  equal = '=',
  notEqual = '!=',
  matchRegexp = '=~',
  matchNotRegexp = '!~',
}

export interface Func {
  name: string;
  argTypes: valueType[];
  variadic: number;
  returnType: valueType;
}

export interface LabelMatcher {
  type: matchType;
  name: string;
  value: string;
}

export interface VectorMatching {
  card: vectorMatchCardinality;
  labels: string[];
  on: boolean;
  include: string[];
}

export type StartOrEnd = 'start' | 'end' | null;

// AST Node Types.

export interface Aggregation {
  type: nodeType.aggregation;
  expr: ASTNode;
  op: aggregationType;
  param: ASTNode | null;
  grouping: string[];
  without: boolean;
}

export interface BinaryExpr {
  type: nodeType.binaryExpr;
  op: binaryOperatorType;
  lhs: ASTNode;
  rhs: ASTNode;
  matching: VectorMatching | null;
  bool: boolean;
}

export interface Call {
  type: nodeType.call;
  func: Func;
  args: ASTNode[];
}

export interface MatrixSelector {
  type: nodeType.matrixSelector;
  name: string;
  matchers: LabelMatcher[];
  range: number;
  offset: number;
  timestamp: number | null;
  startOrEnd: StartOrEnd;
}

export interface Subquery {
  type: nodeType.subquery;
  expr: ASTNode;
  range: number;
  offset: number;
  step: number;
  timestamp: number | null;
  startOrEnd: StartOrEnd;
}

export interface NumberLiteral {
  type: nodeType.numberLiteral;
  val: string; // Can't be 'number' because JS doesn't support NaN/Inf/-Inf etc.
}

export interface ParenExpr {
  type: nodeType.parenExpr;
  expr: ASTNode;
}

export interface StringLiteral {
  type: nodeType.stringLiteral;
  val: string;
}

export interface UnaryExpr {
  type: nodeType.unaryExpr;
  op: unaryOperatorType;
  expr: ASTNode;
}

export interface VectorSelector {
  type: nodeType.vectorSelector;
  name: string;
  matchers: LabelMatcher[];
  offset: number;
  timestamp: number | null;
  startOrEnd: StartOrEnd;
}

export interface Placeholder {
  type: nodeType.placeholder;
  children: ASTNode[];
}

// NB: AST stands for Abstract Syntax Tree
type ASTNode =
  | Aggregation
  | BinaryExpr
  | Call
  | MatrixSelector
  | Subquery
  | NumberLiteral
  | ParenExpr
  | StringLiteral
  | UnaryExpr
  | VectorSelector
  | Placeholder;

export default ASTNode;
